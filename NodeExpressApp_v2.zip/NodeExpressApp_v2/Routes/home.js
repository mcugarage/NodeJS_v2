var express = require('express');
var router = express.Router();
var vm = require('../Model/IndexBL.js');



router.get('/', function (req, res) {
    
    vm.GetEmployees(
        function (data) {
            res.render('index', { recordset: data });
        }
    );
});

//router.get('/home', function (req, res) {
//    vm.GetOffices(
//        function (data) {
//            res.render('Home/home', { recordset: data });
//        }
//    );
//    });

    router.get('/EditDetails/:id', function (req, res) {
        var EmpId = req.params.id;
        vm.GetCurrentEmployees(EmpId,
            function (data) {
                res.render('Home/NewEmployeeDiaglog', { recordset: data });
            }
        );
    });

    router.get('/DeleteDetails/:id', function (req, res) {
        var EmpId = req.params.id;
        console.log(EmpId);
                vm.DeleteEmployee(EmpId,
                    function (data) {
                            res.redirect('/');
                
                    }
                );
    });

module.exports = router;