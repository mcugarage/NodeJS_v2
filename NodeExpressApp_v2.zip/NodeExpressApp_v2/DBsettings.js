module.exports = {

    mysql: function () {
        var mysql = require('mysql');
        var connection = mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: '',
            database: 'classicmodels'
        });
        return connection;
    }

}
