var Index = new function () {
    self = this

    this.Ready = function () {

        $('.EditRecord').on('click', function () {
            var id = $(this).attr('data-s-id');
            $.ajax({
                url: "/EditDetails/" + id,
                type: 'GET',
                data: ''
            }).done(function (dataResponse) {
                $('#idAppendModals').html(dataResponse);
                $('.modal').modal('show');
            });
        });

//        $('.DeleteRecord').on('click', function () {
//            var id = $(this).attr('data-s-id');
//            $.ajax({
//                url: "/DeleteDetails/" + id,
//                type: 'POST',
//                data: ''
//            }).done(function (dataResponse) {
//            });
//        });

    }

    this.Check = function (data) {
        var temp = data;
    }

}
$(document).ready(Index.Ready);