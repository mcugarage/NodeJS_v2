var DBsettings = require('../DBsettings.js');

module.exports = {

    GetEmployees: function (callback) {
        var connection = DBsettings.mysql();
        connection.connect();
        connection.query('select * from employees', function (err, response) {
            if (err) throw err
            callback(response);
        });
        connection.end();
    },

//    GetOffices: function (callback) {
//        var connection = DBsettings.mysql();
//        connection.connect();
//        connection.query('select * from offices', function (err, response) {
//            if (err) throw err
//            callback(response);
//        });
//        connection.end();
//    },

    GetCurrentEmployees: function (EmpId,callback) {
        var connection = DBsettings.mysql();
        connection.connect();
        connection.query("select * from employees where employeeNumber = '" + EmpId + "'", function (err,rows, response) {
            if (err) throw err
            callback(rows);
        });
        connection.end();
    },

    DeleteEmployee: function (EmpId,callback) {
        var connection = DBsettings.mysql();
        connection.connect();
        connection.query("DELETE from employees where employeeNumber = '" + EmpId + "'", function (err, response) {
            if (err) throw err
            callback();
        });
        connection.end();
    }

}
