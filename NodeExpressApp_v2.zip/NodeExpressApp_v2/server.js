var express = require('express');
var app     = express();
var port    =   process.env.PORT || 3000;
var path = require('path');
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.listen(port);
console.log('Magic happens on port ' + port);

//To set search path for views to render them
app.set('Views', path.join(__dirname, 'Views'));
app.set('view engine', 'ejs');

//To include all the routes written in any file in routes folder
var RoutesArray = ['home','user']
for(var i = 0; i < RoutesArray.length; i++)
{
var routes = require('./routes/' + RoutesArray[i]);
app.use('/', routes);
}

//To include static file like css and js from content folder
app.use(express.static(__dirname + '/Content'));



	